$('#but').click(function () {
  $('#wiki').fadeOut(1000);
});
